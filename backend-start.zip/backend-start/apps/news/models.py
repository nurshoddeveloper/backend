from django.db import models
from core.models import BaseModel


class New(BaseModel):
    name = models.CharField(max_length=255, verbose_name="Название")

    def __str__(self):
        return str(self.name)

    class Meta:
        db_table = 'news_news_model'


class NewCategory(BaseModel):
    name = models.CharField(max_length=255, verbose_name="Название")

    def __str__(self):
        return str(self.name)

    class Meta:
        db_table = 'news_categories'
