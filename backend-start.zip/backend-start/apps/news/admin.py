from django.contrib import admin

from news.models import New, NewCategory


@admin.register(New)
class NewAdmin(admin.ModelAdmin):
    fields = ('name',)


@admin.register(NewCategory)
class NewCategoryAdmin(admin.ModelAdmin):
    fields = ('name',)

