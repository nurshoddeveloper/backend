# from django.urls import path
#
# urlpatterns = [
#     path('news', NewListView.as_view(), name='new-list'),
#     path('new/<int:pk>', NewDetailView.as_view(), name='new-detail'),
#     path('new-categories', NewCategoriesListView.as_view(), name='new-list'),
#     path('new-category/<int:pk>', NewCategoryDetailView.as_view(), name='new-detail'),
# ]
