from django.contrib import admin

from shop.models import Category, ProductCollection, Product, ProductImage, Characteristic, Comment, CommentImage, \
    CategoryCharacteristicType, CategoryCharacteristic


class ProductImageInline(admin.TabularInline):
    extra = 5
    model = ProductImage
    fields = ('product', 'image')


class CommentImageInline(admin.TabularInline):
    extra = 7
    model = CommentImage
    fields = ('comment', 'image')


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    fields = ('parent', 'name_ru', 'name_uz', 'name_en',)
    list_display = ('parent', 'name_ru', 'name_uz', 'name_en',)


@admin.register(ProductCollection)
class ProductCollectionAdmin(admin.ModelAdmin):
    fields = ('name_ru', 'name_uz', 'name_en',)
    list_display = ('name_ru', 'name_uz', 'name_en',)


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    fields = ('category', 'collection', 'region', 'name_ru', 'name_uz', 'name_en',
              'price', 'description_ru', 'description_uz', 'description_en', 'is_active',)
    list_display = ('category', 'name_ru', 'name_uz', 'name_en', 'description_ru',
                    'description_uz', 'description_en', 'is_active',)
    inlines = [ProductImageInline]


@admin.register(Characteristic)
class CharacteristicAdmin(admin.ModelAdmin):
    fields = ('product', 'name_ru', 'name_uz', 'name_en', 'value_ru', 'value_uz', 'value_en')
    list_display = ('product', 'name_ru', 'name_uz', 'name_en', 'value_ru', 'value_uz', 'value_en')


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    fields = ('product', 'description', 'ratings')
    inlines = [CommentImageInline]


@admin.register(CategoryCharacteristicType)
class CategoryCharacteristicTypeAdmin(admin.ModelAdmin):
    fields = ('category', 'name',)


@admin.register(CategoryCharacteristic)
class CategoryCharacteristicAdmin(admin.ModelAdmin):
    fields = ('name', 'category_characteristic_type',)



