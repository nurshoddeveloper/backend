from modeltranslation.translator import register, TranslationOptions

from shop.models import Product, ProductCollection, Category, Characteristic


@register(Product)
class ProductTranslationOptions(TranslationOptions):
    fields = ('name', 'description')


@register(ProductCollection)
class ProductCollectionTranslationOptions(TranslationOptions):
    fields = ('name',)


@register(Category)
class CategoryTranslationOptions(TranslationOptions):
    fields = ('parent', 'name',)


@register(Characteristic)
class CharacteristicTranslationOptions(TranslationOptions):
    fields = ('name', 'value')


