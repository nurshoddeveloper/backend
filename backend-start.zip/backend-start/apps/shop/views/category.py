from rest_framework.views import APIView
from rest_framework.views import Response
from rest_framework.generics import get_object_or_404

from core.utils.pagination import pagination

from rest_framework.permissions import AllowAny

from shop.models import Category
from shop.serializers.category import CategoryFilterSerializer, CategorySerializer


class CategoryListView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        params = CategoryFilterSerializer.check(request.GET)
        queryset = Category.objects.list(search=params.get('search'))
        serializer = CategorySerializer(queryset, many=True)
        data = pagination(queryset, serializer, params.get('page'), params.get('size'))
        return Response(data)

    def post(self, request):
        serializer = CategorySerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class CategoryDetailView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request, pk):
        instance = get_object_or_404(Category, id=pk)
        data = CategorySerializer(instance).data
        return Response(data)

    def put(self, request, pk):
        instance = get_object_or_404(Category, pk=pk)
        serializer = CategorySerializer(instance, data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def delete(self, request, pk):
        instance = get_object_or_404(Category, id=pk)
        instance.delete()
        return Response({}, 204)
