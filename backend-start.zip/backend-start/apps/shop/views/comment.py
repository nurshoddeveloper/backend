from rest_framework.views import APIView
from rest_framework.views import Response
from rest_framework.generics import get_object_or_404

from core.utils.pagination import pagination

from rest_framework.permissions import AllowAny

from shop.models import Comment
from shop.serializers.comment import CommentFilterSerializer, CommentSerializer


class CommentListView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        params = CommentFilterSerializer.check(request.GET)
        queryset = Comment.objects.list(search=params.get('search'))
        serializer = CommentSerializer(queryset, many=True)
        data = pagination(queryset, serializer, params.get('page'), params.get('size'))
        return Response(data)

    def post(self, request):
        serializer = CommentSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class CommentDetailView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request, pk):
        instance = get_object_or_404(Comment, id=pk)
        data = CommentSerializer(instance).data
        return Response(data)

    def put(self, request, pk):
        instance = get_object_or_404(Comment, id=pk)
        serializer = CommentSerializer(instance, data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def delete(self, request, pk):
        instance = get_object_or_404(Comment, id=pk)
        instance.delete()
        return Response({}, 204)
