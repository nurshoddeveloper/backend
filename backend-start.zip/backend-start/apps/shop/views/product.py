from rest_framework.views import APIView
from rest_framework.views import Response
from rest_framework.generics import get_object_or_404

from core.utils.pagination import pagination
from shop.models import Product, ProductImage
from shop.serializers.product import ProductSerializer, ProductFilterSerializer

from rest_framework.permissions import AllowAny

from shop.serializers.product_image import ProductImageSerializer


class ProductListView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        params = ProductFilterSerializer.check(request.GET)
        queryset = Product.objects.list(search=params.get('search'))
        serializer = ProductSerializer(queryset, many=True)
        data = pagination(queryset, serializer, params.get('page'), params.get('size'))
        return Response(data)

    def post(self, request):
        serializer = ProductSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class ProductDetailView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request, pk):
        instance = get_object_or_404(Product, id=pk)
        data = ProductSerializer(instance).data
        return Response(data)

    def put(self, request, pk):
        instance = get_object_or_404(Product, pk=pk)
        serializer = ProductSerializer(instance, data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def delete(self, request, pk):
        instance = get_object_or_404(Product, id=pk)
        instance.delete()
        return Response({}, 204)


class ProductImagesView(APIView):
    def get(self, request, pk):
        queryset = ProductImage.objects.filter(product=pk)
        serializer = ProductImageSerializer(queryset, many=True)
        return Response(serializer.data)
