from rest_framework.views import APIView
from rest_framework.views import Response
from rest_framework.generics import get_object_or_404

from core.utils.pagination import pagination

from rest_framework.permissions import AllowAny

from shop.models import Characteristic
from shop.serializers.character import CharacterFilterSerializer, CharacterSerializer


class CharacterListView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        params = CharacterFilterSerializer.check(request.GET)
        queryset = Characteristic.objects.list(search=params.get('search'))
        serializer = CharacterSerializer(queryset, many=True)
        data = pagination(queryset, serializer, params.get('page'), params.get('size'))
        return Response(data)

    def post(self, request):
        serializer = CharacterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class CharacterDetailView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request, pk):
        instance = get_object_or_404(Characteristic, id=pk)
        data = CharacterSerializer(instance).data
        return Response(data)

    def put(self, request, pk):
        instance = get_object_or_404(Characteristic, pk=pk)
        serializer = CharacterSerializer(instance, data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def delete(self, request, pk):
        instance = get_object_or_404(Characteristic, id=pk)
        instance.delete()
        return Response({}, 204)
