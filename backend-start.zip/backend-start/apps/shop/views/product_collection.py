from rest_framework.views import APIView
from rest_framework.views import Response
from rest_framework.generics import get_object_or_404

from rest_framework.permissions import AllowAny

from shop.models import ProductCollection
from shop.serializers.product_collection import ProductCollectionSerializer


class ProductCollectionListView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        queryset = ProductCollection.objects.all()
        serializer = ProductCollectionSerializer(queryset, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = ProductCollectionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class ProductCollectionDetailView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request, pk):
        instance = get_object_or_404(ProductCollection, id=pk)
        data = ProductCollectionSerializer(instance).data
        return Response(data)

    def put(self, request, pk):
        instance = get_object_or_404(ProductCollection, pk=pk)
        serializer = ProductCollectionSerializer(instance, data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def delete(self, request, pk):
        instance = get_object_or_404(ProductCollection, id=pk)
        instance.delete()
        return Response({}, 204)
