from rest_framework.views import APIView
from rest_framework.views import Response

from rest_framework.permissions import AllowAny

from shop.models import CategoryCharacteristic
from shop.serializers.category_characteristic import CategoryCharacteristicSerializer


class CategoryCharacteristicListView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        queryset = CategoryCharacteristic.objects.all()
        serializer = CategoryCharacteristicSerializer(queryset, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = CategoryCharacteristicSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)
