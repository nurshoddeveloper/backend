from django.db import models
from core.models import BaseModel
from django.db.models import CASCADE

from shop.querysets.category import CategoryQuerySet
from shop.querysets.character import CharacterQuerySet
from shop.querysets.comment import CommentQuerySet
from shop.querysets.product import ProductQuerySet


class Category(BaseModel):
    parent = models.ForeignKey('self', CASCADE, null=True, blank=True, related_name='categories')
    name = models.CharField(max_length=255, verbose_name="Название")

    objects = CategoryQuerySet.as_manager()

    def __str__(self):
        return str(self.name)

    class Meta:
        db_table = 'shop_categories'


class ProductCollection(BaseModel):
    name = models.CharField(max_length=255, verbose_name="Название",)

    def __str__(self):
        return str(self.name)

    class Meta:
        db_table = 'shop_product_collection'


class Product(BaseModel):
    category = models.ForeignKey('shop.Category', CASCADE, related_name='product')
    collection = models.ManyToManyField('shop.ProductCollection', related_name='products', verbose_name="Коллекция")
    region = models.ManyToManyField('main.Region', related_name='regions', verbose_name='Регион')
    name = models.CharField(max_length=255, verbose_name="Название")
    price = models.IntegerField(default=0, verbose_name="Цена")
    description = models.TextField(verbose_name="Описание")
    is_active = models.BooleanField(default=True)

    objects = ProductQuerySet.as_manager()

    def __str__(self):
        return str(self.name)

    class Meta:
        db_table = 'shop_products'


class CategoryCharacteristicType(BaseModel):
    category = models.ManyToManyField('shop.category', related_name="category_characteristics_type",
                                      verbose_name="Категория")
    name = models.CharField(max_length=255, verbose_name="Категория тип характеристики")

    def __str__(self):
        return str(self.name)


class CategoryCharacteristic(BaseModel):
    category_characteristic_type = models.ManyToManyField('shop.CategoryCharacteristicType',
                                                          related_name="category_characteristic_type",)
    name = models.CharField(max_length=255, verbose_name="Категория характеристики")

    def __str__(self):
        return str(self.name)

    class Meta:
        db_table = 'shop_category_characteristics'


class ProductImage(BaseModel):
    product = models.ForeignKey('shop.Product', CASCADE, 'image')
    image = models.ImageField(upload_to='productImage', null=True, blank=True, verbose_name="Изображение")

    class Meta:
        db_table = 'shop_product_images'


class Characteristic(BaseModel):
    product = models.ForeignKey('shop.Product', CASCADE, verbose_name='Товар')
    name = models.CharField(max_length=255, verbose_name="Название")
    value = models.CharField(max_length=255, verbose_name="Значение")

    objects = CharacterQuerySet.as_manager()

    def __str__(self):
        return str(self.name)

    class Meta:
        db_table = 'shop_characteristics'


class Comment(BaseModel):
    product = models.ForeignKey('shop.Product', CASCADE, verbose_name='Товар')
    description = models.TextField(verbose_name="Описание")
    ratings = models.IntegerField(default=0, verbose_name="Оценки")

    objects = CommentQuerySet.as_manager()

    def __str__(self):
        return str(self.description)

    class Meta:
        db_table = 'shop_comment'


class CommentImage(BaseModel):
    comment = models.ForeignKey('shop.Comment', CASCADE)
    image = models.ImageField(upload_to='commentImage', null=True, blank=True, verbose_name="Изображение")

    class Meta:
        db_table = 'shop_comment_images'
