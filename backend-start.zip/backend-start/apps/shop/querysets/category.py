from core.querysets.base_queryset import BaseQuerySet


class CategoryQuerySet(BaseQuerySet):
    def list(self, category=None, search=None):
        query = self.filter(parent=category) if category else self
        query = query.filter(name__icontains=search) if search else query
        return query.order_by('id')

    def parent(self, ):
        query = self.filter(parent__isnull=True)
        return query
