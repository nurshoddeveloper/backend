from django.urls import path

from shop.views.category import CategoryListView, CategoryDetailView
from shop.views.category_characteristic import CategoryCharacteristicListView
from shop.views.character import CharacterListView, CharacterDetailView
from shop.views.comment import CommentListView, CommentDetailView
from shop.views.product import ProductListView, ProductDetailView, ProductImagesView
from shop.views.product_collection import ProductCollectionListView, ProductCollectionDetailView

urlpatterns = [
    path('products', ProductListView.as_view(), name='product-list'),
    path('product/<int:pk>', ProductDetailView.as_view(), name='product-detail'),
    path('product-images/<int:pk>', ProductImagesView.as_view(), name='product-images'),
    path('categories', CategoryListView.as_view(), name='category-list'),
    path('category/<int:pk>', CategoryDetailView.as_view(), name='category-detail'),
    path('characteristic', CharacterListView.as_view(), name='character-list'),
    path('character/<int:pk>', CharacterDetailView.as_view(), name='character-detail'),
    path('comments', CommentListView.as_view(), name='comment-list'),
    path('comment/<int:pk>', CommentDetailView.as_view(), name='comment-detail'),
    path('product-collection', ProductCollectionListView.as_view(), name='product-collection-list'),
    path('product-collections/<int:pk>', ProductCollectionDetailView.as_view(), name='product-collection-detail'),
    path('category-characteristic', CategoryCharacteristicListView.as_view(), name='category-characteristic-list'),
]
