from rest_framework import serializers
from core.utils.serializers import ValidatorSerializer
from shop.models import Characteristic
from shop.serializers.product import ProductSerializer


class CharacterSerializer(serializers.ModelSerializer):
    def to_representation(self, instance):
        data = super().to_representation(instance)
        data['product'] = ProductSerializer(instance.product).data
        return data

    class Meta:
        model = Characteristic
        fields = ('id', 'product', 'name', 'value')


class CharacterFilterSerializer(ValidatorSerializer):
    page = serializers.IntegerField(default=1)
    size = serializers.IntegerField(default=15)
    search = serializers.CharField(required=False)
