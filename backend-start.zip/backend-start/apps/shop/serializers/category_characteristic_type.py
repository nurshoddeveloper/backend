from rest_framework import serializers

from shop.models import CategoryCharacteristicType


class CategoryCharacteristicTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = CategoryCharacteristicType
        fields = ('id', 'name', 'category',)
