from rest_framework import serializers
from core.utils.serializers import ValidatorSerializer
from main.serializers.region import RegionSerializer
from shop.models import Product, ProductImage, ProductCollection
from shop.serializers.category import CategorySerializer
from shop.serializers.product_image import ProductImageSerializer


class ProductSerializer(serializers.ModelSerializer):
    main_image = serializers.SerializerMethodField()

    def to_representation(self, instance):
        data = super().to_representation(instance)
        data['category'] = CategorySerializer(instance.category).data
        data['region'] = RegionSerializer(instance.region.all(), many=True).data
        data['image'] = ProductImageSerializer(instance.image.all(), many=True).data
        return data

    def get_main_image(self, obj):
        image = ProductImage.objects.filter(product=obj).first()
        data = ProductImageSerializer(image).data['image']
        return data

    class Meta:
        model = Product
        fields = ('id', 'category', 'region', 'name', 'price', 'description', 'is_active', 'image', 'main_image',)


class ProductFilterSerializer(ValidatorSerializer):
    page = serializers.IntegerField(default=1)
    size = serializers.IntegerField(default=15)
    search = serializers.CharField(required=False)

