from rest_framework import serializers
from core.utils.serializers import ValidatorSerializer
from shop.models import Category


class CategorySerializer(serializers.ModelSerializer):
    def to_representation(self, instance):
        from shop.serializers.product import ProductSerializer
        data = super().to_representation(instance)
        data['products'] = ProductSerializer(instance.product.all(), many=True).data
        return data

    class Meta:
        model = Category
        fields = ('id', 'parent', 'name')


class CategoryFilterSerializer(ValidatorSerializer):
    page = serializers.IntegerField(default=1)
    size = serializers.IntegerField(default=15)
    category = serializers.PrimaryKeyRelatedField(queryset=Category.objects.all(), required=False)
    search = serializers.CharField(required=False)

