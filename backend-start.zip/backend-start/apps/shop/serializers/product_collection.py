from rest_framework import serializers
from shop.models import ProductCollection


class ProductCollectionSerializer(serializers.ModelSerializer):
    def to_representation(self, instance):
        from shop.serializers.product import ProductSerializer
        data = super().to_representation(instance)
        data['products'] = ProductSerializer(instance.products.all(), many=True).data
        return data

    class Meta:
        model = ProductCollection
        fields = ('id', 'name',)
