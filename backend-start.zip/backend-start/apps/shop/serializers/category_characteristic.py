from rest_framework import serializers

from shop.models import CategoryCharacteristic
from shop.serializers.category_characteristic_type import CategoryCharacteristicTypeSerializer


class CategoryCharacteristicSerializer(serializers.ModelSerializer):
    def to_representation(self, instance):
        data = super().to_representation(instance)
        data['category_characteristic_type'] = CategoryCharacteristicTypeSerializer(instance.category_characteristic_type.all(), many=True).data
        return data

    class Meta:
        model = CategoryCharacteristic
        fields = ('id', 'name', 'category_characteristic_type',)
