from rest_framework import serializers
from core.utils.serializers import ValidatorSerializer
from shop.models import Comment
from shop.serializers.product import ProductSerializer


class CommentSerializer(serializers.ModelSerializer):
    def to_representation(self, instance):
        data = super().to_representation(instance)
        data['product'] = ProductSerializer(instance.product).data
        return data

    class Meta:
        model = Comment
        fields = ('id', 'product', 'description', 'ratings')


class CommentFilterSerializer(ValidatorSerializer):
    page = serializers.IntegerField(default=1)
    size = serializers.IntegerField(default=15)
    search = serializers.CharField(required=False)

