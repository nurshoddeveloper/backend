PICKUP = 'pickup'
DELIVERY = 'delivery'

DELIVERY_TYPES = (
    (PICKUP, 'Самовывоз'),
    (DELIVERY, 'Доставка'),
)
