from django.db.models import QuerySet


class BaseQuerySet(QuerySet):
    pass
