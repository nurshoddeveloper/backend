from django.db import models
from core.models import BaseModel
from django.db.models import CASCADE
from django.utils.translation import gettext_lazy as _


class Region(BaseModel):
    name = models.CharField(max_length=255, verbose_name="Регион")

    def __str__(self):
        return self.name


class Company(BaseModel):
    SUM = 'sum'
    DOLLAR = 'dollar'
    NEGOTIABLE = 'negotiable'

    VALUE_STATUS = (
        (SUM, _('Цена в сумах')),
        (DOLLAR, _('Цена в у.е.')),
        (NEGOTIABLE, _('Договорная цена')),
    )

    name = models.CharField(max_length=255, verbose_name="Заголовок")
    category = models.ManyToManyField('shop.Category', verbose_name='Категория', related_name="category")
    price_type = models.CharField(max_length=255, default=SUM, choices=VALUE_STATUS, verbose_name='Тип цены')
    price = models.IntegerField(default=0, verbose_name='Цена')
    description = models.TextField(verbose_name="Описание")
    region = models.ForeignKey('main.Region', CASCADE, null=True, blank=True, verbose_name='Регион')
    phone = models.CharField(max_length=255, verbose_name='Телефон')
    company = models.CharField(max_length=255, verbose_name='Компания')
    address = models.CharField(max_length=255, verbose_name='Адрес')
    email = models.EmailField(null=True, blank=True, unique=True, verbose_name='Эл. почта')
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class CompanyImage(BaseModel):
    company = models.ForeignKey('main.Company', CASCADE, 'image')
    image = models.ImageField(upload_to='companyImage', verbose_name="Фотографии", null=True, blank=True)

    def __str__(self):
        return self.company.name
