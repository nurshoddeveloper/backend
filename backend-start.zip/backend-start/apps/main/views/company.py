from rest_framework.views import APIView
from rest_framework.views import Response
from rest_framework.generics import get_object_or_404

from rest_framework.permissions import AllowAny

from main.models import Company
from main.serializers.company import CompanySerializer


class CompanyListView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        queryset = Company.objects.all()
        serializer = CompanySerializer(queryset, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = CompanySerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class CompanyDetailView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request, pk):
        instance = get_object_or_404(Company, id=pk)
        data = CompanySerializer(instance).data
        return Response(data)

    def put(self, request, pk):
        instance = get_object_or_404(Company, pk=pk)
        serializer = CompanySerializer(instance, data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def delete(self, request, pk):
        instance = get_object_or_404(Company, id=pk)
        instance.delete()
        return Response({}, 204)
