from rest_framework.views import APIView
from rest_framework.views import Response
from rest_framework.generics import get_object_or_404

from rest_framework.permissions import AllowAny

from main.models import Region
from main.serializers.region import RegionSerializer


class RegionListView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        queryset = Region.objects.all()
        serializer = RegionSerializer(queryset, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = RegionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class RegionDetailView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request, pk):
        instance = get_object_or_404(Region, id=pk)
        data = RegionSerializer(instance).data
        return Response(data)

    def put(self, request, pk):
        instance = get_object_or_404(Region, pk=pk)
        serializer = RegionSerializer(instance, data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def delete(self, request, pk):
        instance = get_object_or_404(Region, id=pk)
        instance.delete()
        return Response({}, 204)
