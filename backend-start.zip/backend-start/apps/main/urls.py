from django.urls import path

from main.views.region import RegionListView, RegionDetailView
from main.views.company import CompanyListView, CompanyDetailView

urlpatterns = [
    path('regions', RegionListView.as_view(), name='region-list'),
    path('region/<int:pk>', RegionDetailView.as_view(), name='region-detail'),
    path('companies', CompanyListView.as_view(), name='company-list'),
    path('company/<int:pk>', CompanyDetailView.as_view(), name='company-detail'),
]
