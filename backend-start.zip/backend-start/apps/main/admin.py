from django.contrib import admin

from main.models import Region, CompanyImage, Company


class CompanyImageInline(admin.TabularInline):
    extra = 5
    model = CompanyImage
    fields = ('image', 'company')


@admin.register(Region)
class RegionAdmin(admin.ModelAdmin):
    fields = ('name_ru', 'name_uz', 'name_en',)
    list_display = ('name_ru', 'name_uz', 'name_en',)


@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    fields = (
        'name_ru',
        'name_uz',
        'name_en',
        'category',
        'price_type',
        'price',
        'description_ru',
        'description_uz',
        'description_en',
        'region',
        'phone',
        'company_ru',
        'company_uz',
        'company_en',
        'address_ru',
        'address_uz',
        'address_en',
        'email',
        'is_active',
    )
    inlines = [CompanyImageInline]
