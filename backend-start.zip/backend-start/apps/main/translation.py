from modeltranslation.translator import register, TranslationOptions

from main.models import Region, Company


@register(Region)
class RegionTranslationOptions(TranslationOptions):
    fields = ('name',)


@register(Company)
class CompanyTranslationOptions(TranslationOptions):
    fields = ('name', 'description', 'company', 'address',)
