from rest_framework import serializers

from main.models import CompanyImage


class CompanyImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = CompanyImage
        fields = ('id', 'company', 'image',)
