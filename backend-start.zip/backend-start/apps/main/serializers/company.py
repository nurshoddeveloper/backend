from rest_framework import serializers
from main.models import Company, CompanyImage
from main.serializers.company_image import CompanyImageSerializer
from shop.serializers.category import CategorySerializer


class CompanySerializer(serializers.ModelSerializer):
    image = serializers.SerializerMethodField()

    def to_representation(self, instance):
        data = super().to_representation(instance)
        data['category'] = CategorySerializer(instance.category.all(), many=True).data
        data['region'] = CategorySerializer(instance.region).data
        return data

    def get_image(self, obj):
        image = CompanyImage.objects.filter(company=obj).first()
        data = CompanyImageSerializer(image).data['image']
        return data

    class Meta:
        model = Company
        fields = (
            'id', 'name', 'category', 'price_type', 'price', 'description',
            'region', 'phone', 'company', 'address', 'email', 'image', 'is_active',
        )
