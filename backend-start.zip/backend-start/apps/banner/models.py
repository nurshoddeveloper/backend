from django.db import models
from core.models import BaseModel
from core.utils.files import file_path


class Banner(BaseModel):
    HOME_PAGE_MAIN = 'home page main'
    HOME_PAGE_BODY = 'home page body'
    CATALOG_PAGE_MAIN = 'catalog page main'
    CATALOG_PAGE_BODY = 'catalog page body'
    COMPANY_PAGE_MAIN = 'company page main'
    COMPANY_PAGE_BODY = 'company page body'

    TYPE_PAGE = (
        (HOME_PAGE_MAIN, 'Home page main'),
        (HOME_PAGE_BODY, 'Home page body'),
        (CATALOG_PAGE_MAIN, 'Catalog page main'),
        (CATALOG_PAGE_BODY, 'Catalog page body'),
        (COMPANY_PAGE_MAIN, 'Company page main'),
        (COMPANY_PAGE_BODY, 'Company page body')
    )

    is_active = models.BooleanField(default=True)
    title = models.CharField(max_length=255, unique=True)
    link = models.CharField(max_length=255, unique=True)
    image = models.ImageField(upload_to=file_path('banner/{id}/', 'image'), null=True, blank=True)
    page = models.CharField(max_length=255, choices=TYPE_PAGE)
