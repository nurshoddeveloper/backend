from django.urls import path
from banner.views.banner import BannerListView, BannerDetailView

urlpatterns = [
    path('banners', BannerListView.as_view(), name='banner-list'),
    path('banner/<int:pk>', BannerDetailView.as_view(), name='banner-detail'),
    # path('banner-categories', BannerCategoriesListView.as_view(), name='banner-list'),
    # path('banner-category/<int:pk>', BannerCategoryDetailView.as_view(), name='banner-detail'),
]
