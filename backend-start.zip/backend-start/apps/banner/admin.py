from django.contrib import admin

from banner.models import Banner


@admin.register(Banner)
class BannerAdmin(admin.ModelAdmin):
    fields = ('title', 'image', 'link', 'is_active', 'page')
