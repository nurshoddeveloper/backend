from rest_framework.views import APIView
from rest_framework.views import Response
from rest_framework.generics import get_object_or_404
from rest_framework.permissions import AllowAny
from banner.models import Banner
from banner.serializers.banner import BannerSerializer


class BannerListView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        queryset = Banner.objects.all()
        serializer = BannerSerializer(queryset, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = BannerSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class BannerDetailView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request, pk):
        instance = get_object_or_404(Banner, id=pk)
        data = BannerSerializer(instance).data
        return Response(data)

    def put(self, request, pk):
        instance = get_object_or_404(Banner, pk=pk)
        serializer = BannerSerializer(instance, data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def delete(self, request, pk):
        instance = get_object_or_404(Banner, id=pk)
        instance.delete()
        return Response({}, 204)
