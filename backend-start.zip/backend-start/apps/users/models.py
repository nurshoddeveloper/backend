import binascii
import os
import random
from datetime import timedelta

from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone
from django.utils.translation import ugettext as _

from config.settings import SEND_CONFIRMATION_SMS
from core.models import BaseModel
from core.utils.files import file_path
from users.querysets.confirmation import ConfirmationQuerySet
from users.querysets.users import UsersManager


class User(AbstractUser):
    ADMIN = 'admin'
    CUSTOMER = 'customer'
    SELLER = 'seller'
    MANAGER = 'manager'
    COURIER = 'courier'

    TYPES = (
        (ADMIN, 'Админ'),
        (CUSTOMER, 'Клиент'),
        (SELLER, 'Продавец'),
        (MANAGER, 'Менеджер'),
        (COURIER, 'Курьер')
    )

    phone = models.CharField(max_length=20, null=True, blank=True, verbose_name=_('Номер телефона'))
    language = models.CharField(max_length=255, default='ru')
    image = models.ImageField(upload_to=file_path('user/{id}/', 'photo'), null=True, blank=True)
    email = models.EmailField(null=True, blank=True, unique=True)
    type = models.CharField(max_length=255, choices=TYPES, default=CUSTOMER)
    country_code = models.IntegerField(default=998)
    address = models.CharField(max_length=255, null=True, blank=True)
    shop_name = models.CharField(max_length=255, null=True, blank=True)

    objects = UsersManager()

    class Meta(AbstractUser.Meta):
        app_label = 'users'


class Device(BaseModel):
    user = models.ForeignKey('users.User', models.CASCADE, 'devices')
    token = models.CharField(max_length=255)


class ConfirmationCode(BaseModel):
    AUTHENTICATION = 'authentication'
    CHANGE_PHONE = 'change_phone'

    TYPES = (
        (AUTHENTICATION, _('Авторизация')),
        (CHANGE_PHONE, _('Смена телефона'))
    )

    type = models.CharField(max_length=255, choices=TYPES, default=AUTHENTICATION)
    phone = models.CharField(max_length=20, verbose_name=_('Номер телефона'))
    user = models.ForeignKey(User, models.CASCADE, verbose_name=_('Пользователь'))
    code = models.CharField(max_length=20, verbose_name=_('Код подтверждения'))
    is_used = models.BooleanField(default=False, verbose_name=_('Был использован?'))
    expires_at = models.DateTimeField(verbose_name=_('Срок действия'))

    objects = ConfirmationQuerySet.as_manager()

    def save(self, *args, **kwargs):
        self.code = str(random.randint(1000, 9999)) if SEND_CONFIRMATION_SMS else "0000"
        self.expires_at = timezone.now() + timedelta(hours=2)
        return super().save(*args, **kwargs)

    def send(self):
        if not SEND_CONFIRMATION_SMS:
            return

        import requests
        headers = {
            'Content-Type': 'Content-Type: application/json',
            'Authorization': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJhZG1pbiIsImlhdCI6MTYxNDQyOTE1NiwiZXhwIjo0MTAyNDQ0ODAwLCJ1aWQiOjg3NDc1LCJyb2xlcyI6WyJST0xFX1VTRVIiXX0.2_Fz0vYGay64Ps1gbYVnsdb2b38KZMckM_uB0upat94'
        }

        data = '[{' + f'"phone_number": "+{self.user.country_code}{self.user.phone}",' \
                      f' "message": "Your activation code for the application Garage24 {self.code}",' \
                      f' "device_id": 123318'\
               + '}]'

        requests.post(
            "https://smsgateway.me/api/v4/message/send",
            headers=headers,
            data=data
        ).json()

    def __str__(self):
        return str(self.code) or 'n/a'

    class Meta:
        get_latest_by = 'id'
        db_table = 'users_confirmation_codes'
        verbose_name = _('Код подтверждения')
        verbose_name_plural = _('Коды подтверждения')


class Token(BaseModel):
    key = models.CharField(max_length=40, verbose_name=_("Ключ"), unique=True)
    user = models.ForeignKey(User, models.CASCADE, related_name='tokens', verbose_name=_("Пользователь"))

    def save(self, *args, **kwargs):
        if not self.key:
            self.key = binascii.hexlify(os.urandom(20)).decode()

        return super(Token, self).save(*args, **kwargs)

    def __str__(self):
        return self.key

    class Meta:
        db_table = 'users_tokens'
        verbose_name = _("Ключ доступа")
        verbose_name_plural = _("Ключи доступа")


class Bank(BaseModel):
    name = models.CharField(max_length=255)
    checking_account = models.CharField(max_length=255)
    mfo = models.CharField(max_length=255)
    inn = models.CharField(max_length=255)
    oked = models.CharField(max_length=255)
    user = models.OneToOneField('users.User', models.CASCADE)

    class Meta:
        db_table = 'users_banks'
