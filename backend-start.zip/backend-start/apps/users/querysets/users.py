from django.contrib.auth import models
from django.db.models import Q

from core.utils.helpers import integers_only


class UsersManager(models.UserManager):
    def sign_in(self, phone, language, type):
        from users.models import ConfirmationCode

        phone = integers_only(phone)
        user, created = self.get_or_create(
            phone=phone,
            language=language,
            defaults={'username': phone, 'password': ''}
        )
        user.type = type
        user.save()

        confirmation = ConfirmationCode.objects.create(
            user=user,
            phone=phone,
            created_by=user,
            type=ConfirmationCode.AUTHENTICATION
        )
        confirmation.send()
        return user, confirmation.code

    def list(self, type=None, search=None):
        query = self.filter(type=type) if type else type

        if search:
            search_criteria = (
                Q(first_name__icontains=search) |
                Q(last_name__icontains=search) |
                Q(email__icontains=search)
            )

            if integers_only(search):
                search_criteria = search_criteria | Q(phone__contains=integers_only(search))

            query = query.filter(search_criteria)

        return query.order_by('-id')
