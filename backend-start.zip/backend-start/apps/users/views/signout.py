from rest_framework.generics import GenericAPIView
from rest_framework.response import Response

from users.models import Token, Device


class SignOutView(GenericAPIView):
    def delete(self, request):
        Device.objects.filter(user=request.user, token=request.GET.get('device_token')).delete()
        Token.objects.filter(key=request.auth.key, user=request.user).delete()
        return Response()
