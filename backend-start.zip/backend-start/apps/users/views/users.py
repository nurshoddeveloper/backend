from rest_framework.views import APIView
from rest_framework.generics import get_object_or_404
from rest_framework.response import Response
from users.serializers.users import UserSerializer, UserAvatarSerializer
from users.models import User


class UserSettingsView(APIView):
    def put(self, request):
        instance = get_object_or_404(User, id=request.user.id)
        serializer = UserSerializer(instance, data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save(updated_by=request.user)
        return Response(serializer.data)


class UserAvatarSettingsView(APIView):
    def put(self, request):
        instance = get_object_or_404(User, id=request.user.id)
        serializer = UserAvatarSerializer(instance, data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save(updated_by=request.user)
        return Response(serializer.data)

    def delete(self, request):
        instance = get_object_or_404(User, id=request.user.id)
        instance.image.delete()
        instance.save()
        return Response({}, 200)
