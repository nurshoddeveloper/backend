from rest_framework.views import APIView
from rest_framework.generics import get_object_or_404
from rest_framework.response import Response
from users.serializers.bank import BankSerializer
from users.models import Bank


class BankDetailView(APIView):
    def get(self, request):
        instance = get_object_or_404(Bank, user=request.user)
        serializer = BankSerializer(instance)
        return Response(serializer.data)

    def put(self, request):
        instance = Bank.objects.filter(user=request.user).first()
        serializer = BankSerializer(instance, data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save(created_by=request.user, updated_by=request.user, user=request.user)
        return Response(serializer.data)
