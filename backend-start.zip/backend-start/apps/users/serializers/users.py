from rest_framework import serializers

from core.utils.helpers import integers_only
from users.models import User
from rest_framework.exceptions import ValidationError
from django.utils.translation import ugettext as _


class UserSerializer(serializers.ModelSerializer):
    first_name = serializers.CharField(required=True)

    def update(self, instance, data):
        data['email'] = data.get('email') if data.get('email') else None
        data['username'] = data.get('phone') if data.get('phone') else data.get('email')
        data['phone'] = data.get('phone')
        super().update(instance, data)
        return instance

    class Meta:
        model = User
        fields = ('id', 'first_name', 'last_name', 'language', 'type', 'image', 'email', 'phone', 'country_code',)
        extra_kwargs = {'image': {'read_only': True}}


class UserSimpleSerializer(serializers.ModelSerializer):
    def to_representation(self, instance):
        data = super().to_representation(instance)
        data['name'] = instance.get_full_name()
        return data

    def validate(self, data):
        phone = integers_only(data.get('phone'))

        # if len(phone) != 9:
        #     raise ValidationError({'phone': _("Номер не валидный...")})

        user = User.objects.filter(phone=phone)
        if user.exists():
            raise ValidationError({'phone': _('Пользователь с таким номером уже существует в системе')})

        data['username'] = phone

        return data

    class Meta:
        model = User
        fields = (
            'id',
            'first_name',
            'last_name',
            'language',
            'type',
            'image',
            'email',
            'phone',
            'country_code',
            'shop_name',
            'address'
        )
        extra_kwargs = {'image': {'read_only': True}, 'first_name': {'required': True}}


class UserLanguageSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'language',)


class UserAvatarSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'image')
