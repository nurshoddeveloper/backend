from rest_framework import serializers
from users.models import Bank


class BankSerializer(serializers.ModelSerializer):
    class Meta:
        model = Bank
        fields = ('id', 'name', 'checking_account', 'mfo', 'inn', 'oked')
