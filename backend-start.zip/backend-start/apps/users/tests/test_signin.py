from django.urls import reverse
from django.utils.translation import ugettext as _
from core.tests.base_test import BaseTestCase
from django.test import override_settings


class UsersTest(BaseTestCase):
    fixtures = ('users_and_tokens',)

    @override_settings(SEND_CONFIRMATION_SMS=False)
    def test_signin_and_confirm(self):
        url = reverse('users:signin')

        response = self.client.post(url, {'phone': '911234567', 'type': 'customer', 'country': 'UZ', 'language': 'ru'})
        self.assertEqual(response.status_code, 201)

        response = self.client.post(url, {'phone': '911234567', 'type': 'customer', 'country': 'UZ', 'language': 'ru'})
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data['user'], [_('Повторная отправка SMS возможна через 60 секунд')])

        response = self.client.post(url, {'phone': '998913333333', 'type': 'customer', 'country': 'UZ', 'language': 'ru'})
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data['phone'], [_('Номер не валидный...')])

        response = self.client.post(reverse('users:confirm'), {'phone': '913106622', 'code': '0000', 'language': 'ru',
                                                               'expo_token': 'sadasd8qweqeqwWWAfsdf'})
        self.assertEqual(response.data['code'], [_('Неверный код подтверждения')])
        self.assertEqual(response.status_code, 400)

    @override_settings(SEND_CONFIRMATION_SMS=True)
    def test_security(self):
        url = reverse('users:signin')
        data = {'phone': '911234567', 'country': 'UZ', 'type': 'customer', 'language': 'ru'}

        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 201)

        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 429)

    def test_tokens(self):
        self.client.credentials(HTTP_AUTHORIZATION='Token asuwhhwhwhehhedhdhddsjhfgsdf')
        response = self.client.post(reverse('main:car-list'))
        self.assertEqual(response.status_code, 401)

        self.client.credentials(HTTP_AUTHORIZATION='Token 5e84409f824bae3e5aa03a3efe4313c9')
        response = self.client.post(reverse('main:car-list'))
        self.assertEqual(response.status_code, 401)
        self.assertEqual(getattr(response.data['detail'], 'code', ''), 'authentication_failed')
