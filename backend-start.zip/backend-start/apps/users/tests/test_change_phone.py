from core.tests.base_test import BaseTestCase
from core.utils.helpers import integers_only
from users.models import ConfirmationCode
from users.tests.constants import USER_TOKEN
from django.urls import reverse
from django.utils.translation import ugettext as _
from django.test import override_settings


class ChangePhoneTest(BaseTestCase):
    fixtures = ('users_and_tokens',)

    def setUp(self):
        self.client.credentials(HTTP_AUTHORIZATION='Token ' + USER_TOKEN)

    @override_settings(SEND_CONFIRMATION_SMS=False)
    def test_change_phone(self):
        phone = '+998901111111'
        url = reverse('users:change-phone')
        response = self.client.post(url, {'phone': phone})
        self.assertEqual(response.status_code, 200, response.data)

        confirm = ConfirmationCode.objects.filter(phone=integers_only(phone)).first()
        url = reverse('users:confirm-change-form')
        response = self.client.post(url, {'phone': phone, 'code': confirm.code})
        self.assertEqual(response.status_code, 200)

        data = {'phone': phone, 'code': 12345532}
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data['code'], [_('Неверный код подтверждения')])

    @override_settings(SEND_CONFIRMATION_SMS=False)
    def test_phone_exists(self):
        phone = '+998913333333'
        url = reverse('users:change-phone')
        response = self.client.post(url, {'phone': phone})
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data['phone'], [_('Пользователь с таким номером уже существует.')])

    @override_settings(SEND_CONFIRMATION_SMS=True)
    def test_security(self):
        phone = '+998901111111'
        url = reverse('users:change-phone')
        response = self.client.post(url, {'phone': phone})
        self.assertEqual(response.status_code, 200, response.data)

        response = self.client.post(url)
        self.assertEqual(response.status_code, 429)
