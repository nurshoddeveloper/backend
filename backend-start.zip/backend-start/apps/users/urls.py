from django.urls import path

from users.views.bank import BankDetailView
from users.views.signin import SignInView, ConfirmationView, ChangeNameView, ChangeLanguageView, SignInEmailView
from users.views.change_phone import ChangePhoneView, ConfirmChangePhoneView
from users.views.signout import SignOutView
from users.views.users import UserAvatarSettingsView, UserSettingsView

urlpatterns = [
    path('user_change_settings', UserSettingsView.as_view(), name='user_change_settings'),
    path('user_change_avatar', UserAvatarSettingsView.as_view(), name='user_change_avatar'),
    path('signin', SignInView.as_view(), name='signin'),
    path('signin-email', SignInEmailView.as_view(), name='signin-email'),
    path('confirm', ConfirmationView.as_view(), name='confirm'),
    path('change_name', ChangeNameView.as_view(), name='change-name'),
    path('change_language', ChangeLanguageView.as_view(), name='change-language'),
    path('change_phone', ChangePhoneView.as_view(), name='change-phone'),
    path('change_phone/confirm', ConfirmChangePhoneView.as_view(), name='confirm-change-form'),
    path('signout', SignOutView.as_view(), name='signout'),
    path('bank-detail', BankDetailView.as_view(), name='bank-detail')
]
