from django.contrib import admin
from django.urls import path, include
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api-auth/', include('rest_framework.urls')),
    path('api/v1/', include([
        path('core/', include(('core.urls', 'core'), namespace='core')),
        path('users/', include(('users.urls', 'user'), namespace='users')),
        path('main/', include(('main.urls', 'main'), namespace='main')),
        path('banner/', include(('banner.urls', 'banner'), namespace='banner')),
        # path('news/', include(('news.urls', 'news'), namespace='news')),
        path('shop/', include(('shop.urls', 'shop'), namespace='shop')),
    ])),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
